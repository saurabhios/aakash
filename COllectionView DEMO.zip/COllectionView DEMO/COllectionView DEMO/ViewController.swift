//
//  ViewController.swift
//  COllectionView DEMO
//
//  Created by Apple on 22/10/19.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

import Alamofire

class cellCollection : UICollectionViewCell {
    @IBOutlet var imgView   : UIImageView!
    @IBOutlet var lblNm     : UILabel!
}

class ViewController: UIViewController {
    
    @IBOutlet var collectionVW : UICollectionView!
    
    var arrCollectionData : [AnyObject] = []
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
                
        let urlComp = URL.init(string: "https://staging.sunteccity.com.sg/ver16/index.php/apitokenv4/list/model/merchant")!
        
        var  params : [String : AnyObject] = [:]
        params["CompanyID"] = 1         as AnyObject
        params["MenuID"]    = 0         as AnyObject
        params["SubCategoryID"] = 0     as AnyObject
        params["ImageSize"] = "small"   as AnyObject
        params["SearchMerchant"] = ""   as AnyObject
        
        var paramsFinal : [String : Any] = [:]
                
        do {
            let data = try JSONSerialization.data(withJSONObject: params, options: [])
            if let string = String(data: data, encoding: String.Encoding.utf8) {
                paramsFinal["params"] = string
            }
        } catch {
            print(error)
        }
        
        
        var headerParams : [String : String] = [:]
        headerParams["issecuritydisable"] = "0"
        headerParams["Content-Type"] = "application/x-www-form-urlencoded"//"application/x-www-form-urlencoded" as AnyObject
        
        print("URL \(urlComp) \n params \(paramsFinal) \n header \(headerParams)")
        
        var request = URLRequest(url: urlComp)
        //request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        //request.setValue("0", forHTTPHeaderField: "issecuritydisable")
        request.httpMethod = "POST"
        request.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        request.addValue("0", forHTTPHeaderField: "issecuritydisable")
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: paramsFinal, options: [])
        } catch {
            print("ERRROR")
        }

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data,
                let response = response as? HTTPURLResponse,
                error == nil else {                                              // check for fundamental networking error
                print("error", error ?? "Unknown error")
                return
            }

            guard (200 ... 299) ~= response.statusCode else {                    // check for http errors
                print("statusCode should be 2xx, but is \(response.statusCode)")
                print("response = \(response)")
                return
            }

            let responseString = String(data: data, encoding: .utf8)
            print("responseString = \(responseString)")
        }

        task.resume()
        
        
        /*Alamofire.request(urlComp,
                          method: .post,
                          parameters: paramsFinal,
                          headers: headerParams).responseJSON
            {
                (responseData) in
                let statusCode = responseData.response?.statusCode
                print(statusCode!)
                if statusCode == 200 {
                    if responseData.result.isSuccess {
                        let responseDict = responseData.result.value as! [String : AnyObject]
                        print(responseDict["PremiumMerchant"] as! [AnyObject])
                        self.arrCollectionData = responseDict["PremiumMerchant"] as! [AnyObject]
                        print(self.arrCollectionData)
                        
                        self.collectionVW.reloadData()
                    }
                }
        }*/
    }
}

extension ViewController : UICollectionViewDelegate, UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.arrCollectionData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell: cellCollection = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! cellCollection
        let dictdata : [String : AnyObject] = self.arrCollectionData[indexPath.row] as! [String : AnyObject]
        cell.lblNm.text = (dictdata["StoreName"] as! String)
        cell.imgView.imageFromServerURL(dictdata["PromotionalImage"] as! String, placeHolder: UIImage.init())
        return cell
    }
}
